# HTF22-Team-105

<h1>HEALTH MONITORING SYSTEM </h1>


<h2>Home Page</h2>

![image](https://user-images.githubusercontent.com/84970944/198868286-9db5318f-58b0-4e7b-8c11-8bff8847b4a5.png)

<h2>Contact Us Page</h2>

![image](https://user-images.githubusercontent.com/84970944/198868331-09e7eecd-64b4-4cde-8d24-a93eeaeb8227.png)

<h3>Login Features</h3>

![image](https://user-images.githubusercontent.com/84970944/198868346-bfb03e60-6367-407c-b966-a925bfcb8825.png)

<h3>Admin Login</h3>

![image](https://user-images.githubusercontent.com/84970944/198868364-dbab43fe-8a22-44e5-8637-b12eadd87149.png)


<h3>Admin Dashboard</h3>

![image](https://user-images.githubusercontent.com/84970944/198868396-3c46f4c3-17e9-4afd-9005-8afa511bd02a.png)


<h2>Admin Features</h2>


<h3>1 Add Doctor Manage Doctors Doctor Specialization </h3>

![image](https://user-images.githubusercontent.com/84970944/198868427-9c2a328c-7485-4ff5-a90f-f27aa4a7b514.png)

![image](https://user-images.githubusercontent.com/84970944/198868541-cf4e062c-7514-4621-8a72-da12507f00f0.png)

![image](https://user-images.githubusercontent.com/84970944/198868555-c12c3ff4-2b1e-4c55-ba50-d4428063c25d.png)



<h3>2 Manage Users Manage Patients</h3>

![image](https://user-images.githubusercontent.com/84970944/198868479-fcca08fb-0a1a-4cdb-9fc8-c3b6d3e7f466.png)

![image](https://user-images.githubusercontent.com/84970944/198868502-d1b38113-dff1-43ff-94f5-f0c423e19ad8.png)

![image](https://user-images.githubusercontent.com/84970944/198868574-73adc297-29f9-426c-9ef8-fc730a556f03.png)

![image](https://user-images.githubusercontent.com/84970944/198868583-c90eacdc-c913-4e93-9bfd-64338e143daf.png)


<h3>3 Appointment History</h3>


![image](https://user-images.githubusercontent.com/84970944/198868620-189ade58-c5f2-40be-9fa2-6f8a61ba2317.png)


<h3>4 Read Queries</h3>

![image](https://user-images.githubusercontent.com/84970944/198868639-0f7aaa9c-411c-4103-9d68-dff20d3d7183.png)


<h3>5 Logged Session Control Doctors and Users</h3>

![image](https://user-images.githubusercontent.com/84970944/198868661-5e8f9ace-6773-4129-882b-2e8c56b98c17.png)

![image](https://user-images.githubusercontent.com/84970944/198868675-08c65c92-971f-4b60-bd40-dce1ebf1d6aa.png)


<h3>6 Patient Reports</h3>

![image](https://user-images.githubusercontent.com/84970944/198868698-dec0c660-9a9e-4c64-bfcc-6c6e5425dc13.png)


<h3>7 View Patient Information</h3>

![image](https://user-images.githubusercontent.com/84970944/198868715-91019867-285e-4cda-b0f1-37f16a688f66.png)

<h2> Doctor Features </h2>

<h3> Doctor Login </h3>

![image](https://user-images.githubusercontent.com/84970944/198869063-970f2ff1-45cf-45ce-a98a-4bd800a9c063.png)

<h3> Doctor Dashboard</h3>

![image](https://user-images.githubusercontent.com/84970944/198869107-f46b202f-f509-48a1-b294-0cf502348e56.png)

<h3> Doctor Appointment History</h3>

![image](https://user-images.githubusercontent.com/84970944/198869119-204abaeb-a667-47bd-9dcc-7a520d099fd6.png)

<h3>Doctor-Patient Medical History and Doctor Prescription</h3>

![image](https://user-images.githubusercontent.com/84970944/198869143-0f4b7d02-47ac-4d95-96e9-a80cd1b0c961.png)

<h1> Patient Features</h1>

<h3> Patient Login </h3>

![image](https://user-images.githubusercontent.com/84970944/198869218-3ca0c28f-d211-4c33-acd1-dbc009bcd7f6.png)

<h3> Patient Dashboard </h3>

![image](https://user-images.githubusercontent.com/84970944/198869238-55256ad9-6715-4951-a582-9be1a788e20c.png)

<h3> Book Appointment </h3>

![image](https://user-images.githubusercontent.com/84970944/198869367-b62782e0-a540-49a6-a862-1db1a183145f.png)

<h3>Patient Medical History</h3>

![image](https://user-images.githubusercontent.com/84970944/198869443-858b076f-eb48-4267-85bb-c51c4ff30705.png)
