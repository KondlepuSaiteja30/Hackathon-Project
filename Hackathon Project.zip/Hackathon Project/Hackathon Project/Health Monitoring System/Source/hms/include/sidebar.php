<div class="sidebar app-aside" id="sidebar">
				<div class="sidebar-container perfect-scrollbar">

<nav>
						
						<div class="navbar-title">
							<span >USER NAVIGATOR</span>
						</div>
						<ul class="main-navigation-menu">
							<li>
								<a href="dashboard.php">
									<div class="item-content">
										<div class="item-media">
											<i class="ti-home"></i>
										</div>
										<div class="item-inner">
											<span class="title">DASHBOARD</span>
										</div>
									</div>
								</a>
							</li>
							<li>
								<a href="book-appointment.php">
									<div class="item-content">
										<div class="item-media">
											<i class="ti-pencil-alt"></i>
										</div>
										<div class="item-inner">
											<span class="title"> BOOK APPOINTMENT </span>
										</div>
									</div>
								</a>
							</li>

							<li>
								<a href="appointment-history.php">
									<div class="item-content">
										<div class="item-media">
											<i class="ti-list"></i>
										</div>
										<div class="item-inner">
											<span class="title"> APPOINTMENT HISTORY </span>
										</div>
									</div>
								</a>
							</li>
<li>
								<a href="manage-medhistory.php">
									<div class="item-content">
										<div class="item-media">
											<i class="ti-list"></i>
										</div>
										<div class="item-inner">
											<span class="title"> MEDICAL HISTORY </span>
										</div>
									</div>
								</a>
							</li>

						</ul>
						
					</nav>
					</div>
			</div>